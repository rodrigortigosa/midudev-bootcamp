import axios from "axios";

const baseUrl = "https://jsonplaceholder.typicode.com/posts";

const getAll = () => {
  //return Promise.reject("API Fail");
  /*
  return axios.get(baseUrl).then((response) => {
    const { data } = response;
    console.log(response);
    return data;
  });
  */
  const request = axios.get(baseUrl);
  return request.then((response) => response.data);
};

const create = (newObject) => {
  //return Promise.reject("API Fail");
  /*
  return axios.post(baseUrl, { title, body, userId }).then((response) => {
    const { data } = response;
    return data;
  });
  */
  const request = axios.post(baseUrl, newObject);
  return request.then((response) => response.data);
};

export default { getAll, create };
