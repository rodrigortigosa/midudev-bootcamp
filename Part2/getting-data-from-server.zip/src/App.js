import "./styles.css";
import React, { useEffect, useState } from "react";
import { Note } from "./components/Note";
import noteService from "./services/notes";

const App = () => {
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    console.log("useEffect");
    setLoading(true);

    setError("");

    noteService
      .getAll()
      .then((notes) => {
        setNotes(notes);
        setLoading(false);
      })
      .catch((error) => {
        console.log(error);
        setError("La API ha petado");
      });
  }, []);

  const handleChange = (event) => {
    setNewNote(event.target.value);
  };

  const handleSubmitAddNote = (event) => {
    event.preventDefault();

    console.log("add note");
    console.log(newNote);

    const noteToAddToState = {
      title: newNote,
      body: newNote,
      userId: 1
    };
    console.log(noteToAddToState);

    setError("");

    noteService
      .create(noteToAddToState)
      .then((note) => {
        setNotes((prevNotes) => prevNotes.concat(note));
      })
      .catch((error) => {
        console.log(error);
        setError("La API ha petado");
      });

    setNewNote("");
  };

  console.log("render");

  return (
    <div>
      <h1>Notes</h1>

      {loading ? "Cargando..." : ""}
      <ol>
        {notes.map((note) => (
          <Note key={note.id} {...note} />
        ))}
      </ol>
      <form onSubmit={handleSubmitAddNote}>
        <input type="text" onChange={handleChange} value={newNote} required />
        <button>Add note</button>
      </form>
      {error ? alert(error) : ""}
    </div>
  );
};

export default App;
