import ReactDOM from "react-dom";
//import App from "./App";
import { useState } from "react";

const rootElement = document.getElementById("root");

const Display = ({ counter }) => <h1>{counter}</h1>;
const Button = ({ handleClick, text }) => (
  <button onClick={handleClick}>{text}</button>
);

const App = (props) => {
  const [counter, updateCounter] = useState(0);

  console.log("render");

  const increment = () => {
    updateCounter((prevCounter) => prevCounter + 1);
  };

  const decrement = () => {
    updateCounter((prevCounter) => prevCounter - 1);
  };

  const reset = () => updateCounter(0);

  const esPar = counter % 2 === 0;
  const mensajePar = esPar ? "Es par" : "Es impar";
  return (
    <div>
      <p>El valor del contador es: </p>
      <Display counter={counter}></Display>
      <p>{mensajePar}</p>
      <Button handleClick={increment} text={"Increment"}>
        Increment
      </Button>
      <Button handleClick={decrement} text={"Decrement"}>
        Decrement
      </Button>
      <Button handleClick={reset} text={"Reset"}>
        Reset
      </Button>
    </div>
  );
};

ReactDOM.render(<App />, rootElement);
