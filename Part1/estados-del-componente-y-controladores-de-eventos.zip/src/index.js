import { useState } from "react";
import ReactDom from "react-dom";

const rootElement = document.getElementById("root");

const Button = ({ onClick, text }) => <button onClick={onClick}>{text}</button>;

const TotalClicks = ({ allClicks }) => {
  if (allClicks.length === 0) {
    return <p>Total clicks: 0</p>;
  }
  return <p>Total clicks: {allClicks.length}</p>;
};

const History = ({ allClicks }) => {
  if (allClicks.length === 0) {
    return <p>The app is used by pressing the buttons</p>;
  }
  return <p>History: {allClicks.join(", ")}</p>;
};

const App = () => {
  /*const [clicks, setClicks] = useState({
    left: 0,
    right: 0
  });*/

  /*
  const handleLeftClick = () => {
    const newClicks = {
      ...clicks,
      left: clicks.left + 1
    };
    setClicks(newClicks);
  };

  const handleRightClick = () => {
    const newClicks = {
      ...clicks,
      right: clicks.right + 1
    };
    setClicks(newClicks);
  };
  */

  /*return (
    <div>
      {left}
      <button onClick={() => setLeft(left + 1)}>
        left
      </button>
      <button onClick={() => setRight(right + 1)}>
        right
      </button>
      {right}
    </div>
  );*/

  //---------------------------------------------------------------------------

  //const [left, setLeft] = useState(0);
  //const [right, setRight] = useState(0);
  const [allClicks, setAll] = useState([]);

  const handleLeftClick = () => {
    //setLeft((prevLeft) => prevLeft + 1);
    //setAll(allClicks.concat("L"));
    setAll((prevAll) => [...prevAll, "L"]);
  };

  const handleRightClick = () => {
    //setRight((prevRight) => prevRight + 1);
    //setAll(allClicks.concat("R"));
    setAll((prevAll) => [...prevAll, "R"]);
  };

  const handleResetClick = () => {
    setAll([]);
  };

  const left = allClicks.filter((click) => click === "L");
  const right = allClicks.filter((click) => click === "R");

  return (
    <div>
      {left.length}
      <Button onClick={handleLeftClick} text="left" />
      <Button onClick={handleRightClick} text="right" />
      {right.length}
      <p>
        <Button onClick={handleResetClick} text="reset" />
      </p>
      <TotalClicks allClicks={allClicks} />
      <History allClicks={allClicks} />
    </div>
  );
};

ReactDom.render(<App />, rootElement);
